export class DailyExpense{
    description:String;
    amount:number;
}