export class DailyTransaction{
    id:number;
    date:String;
    transaction:String;
}