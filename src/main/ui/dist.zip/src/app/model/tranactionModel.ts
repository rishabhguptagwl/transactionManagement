export class Transaction{
    id:number;
    date:string;
    amount:number;
    save:number;
}