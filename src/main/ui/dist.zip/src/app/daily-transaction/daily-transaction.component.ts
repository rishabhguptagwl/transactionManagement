import { dailyTransactionServices } from './../services/dailyTransaction.service';
import { Component, OnInit } from '@angular/core';
import { DailyExpense } from '../model/DailyExpense';
import { stringify } from 'querystring';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-daily-transaction',
  templateUrl: './daily-transaction.component.html',
  styleUrls: ['./daily-transaction.component.css']
})
export class DailyTransactionComponent implements OnInit {

  constructor(private _dailyTransactionService: dailyTransactionServices,private snackBar: MatSnackBar) { }

  DailyTransaction: number;
  todayDate:any;

  ngOnInit() {
    this.todayDate = new Date();
    this.DailyTransaction = 1;
    this._dailyTransactionService.getAllTransaction().subscribe((data) => {
      console.log(data);
    }, (error) => {
      console.log(error);
    });
  }


  incDailyTransaction() {
    this.DailyTransaction++;
  }

  decDailyTransaction() {
    if (this.DailyTransaction != 1)
      this.DailyTransaction--;
  }


  createRange(number) {
    var items: number[] = [];
    for (var i = 1; i <= number; i++) {
      items.push(i);
    }
    return items;
  }

  showAlert(currentElementIndex) {
    alert(currentElementIndex);
  }


  saveDailyTransaction(form: any) {
    form.value.transDate=this.todayDate;
    // console.log(form.value,this.todayDate);
    this._dailyTransactionService.saveTransaction(form.value, this.DailyTransaction).subscribe((data) => {
      if (stringify(data).split("=")[1] === "Success") {
        this.openSnackBar("Transaction save","Success");
        this.DailyTransaction = 0;
        setTimeout(() => {
          this.DailyTransaction=1;  
        }, 20);
        
      }
    });
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

}