import { DailyTransaction } from './../model/DailyTransaction.Model';
import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class dailyTransactionServices{

    constructor(private _http:HttpClient){
    }

    public getAllTransaction():Observable<DailyTransaction[]>{
        return this._http.get<DailyTransaction[]>("http://192.168.43.49:8080/account/monthtilldate").pipe();
    }
    

    public saveTransaction(data,length):Observable<string>{
        var d = {"data":data,"length":length};
        return this._http.post<string>("http://192.168.43.49:8080/account/dailytransaction/savetest",d).pipe();
    }

    public getTransactionByDate(form:string ,to:string):Observable<DailyTransaction[]>{
        var tmp = "{\"form\":\""+form+"\",\"to\":\""+to+"\"}";
        return this._http.post<DailyTransaction[]>("http://192.168.43.49:8080/account/getdailytransactionbydate",tmp).pipe();
    }

    public getTransactionWeekly(date:string):Observable<DailyTransaction[]>{
        var tmp = "{\"date\":\""+date+"\"}";
        return this._http.post<DailyTransaction[]>("http://192.168.43.49:8080/account/WeeklyTransaction",tmp).pipe();
    }

    public getTransactionToday(date:string):Observable<String>{
        var tmp = "{\"date\":\""+date+"\"}";
        return this._http.post<String>("http://192.168.43.49:8080/account/todaytransaction",tmp).pipe();
    }
    
    public getUnclassTransaction():Observable<object[]>{
        return this._http.get<object[]>("http://192.168.43.49:8080/account/unclasstransaction").pipe();
    }


    public saveUnclassTransaction(data:string,id:string,size:number):Observable<string>{
        var d = {"id":id,"data":data,"size":size};
        return this._http.post<string>("http://192.168.43.49:8080/account/unclass/save",d).pipe();
    }

    public getTransactionByClass(date:string):Observable<Object[]>{
        var tmp = "{\"date\":\""+date+"\"}";
        // alert("service called");
        var tmpe:Observable<Object[]>;
        tmpe =  this._http.post<Object[]>("http://192.168.43.49:8080/account/dailytransaction/Transactionbyclass",tmp).pipe();
        // alert("service return data");
        return tmpe;
    }

    public getMonthlyTransaction(month:string,year:string):Observable<string>{
        var load = {"month":month,"year":year};
        return this._http.post<string>("http://192.168.43.49:8080/account/dailytransaction/transactionMonthly",load).pipe();
    }


    public monthly():Observable<string>{
        return this._http.post<string>("http://192.168.43.49:8080/account/monthlytransaction",{role:1}).pipe();
    }

    public getMonthlyStats(month:string,year:string):Observable<string>{
        var load = {"month":month,"year":year};
        return this._http.post<string>("http://192.168.43.49:8080/account/dailytransaction/transactionmonthlystats",load).pipe();
    }


    public getIncomeOfUser(month:string,year:string):Observable<string>{
        var load = {"month":month,"year":year};
        return this._http.post<string>("http://192.168.43.49:8080/account/income/getuserincome",load);
    }


    public SaveIncomeOfUser(month:string,year:string,income:string):Observable<string>{
        var load = {"month":month,"year":year,"income":income};
        return this._http.post<string>("http://192.168.43.49:8080/account/income/saveincome",load);
    }

    public updateIncomeOfUser(month:string,year:string,income:string):Observable<string>{
        var load = {"month":month,"year":year,"income":income};
        return this._http.post<string>("http://192.168.43.49:8080/account/income/updateincome",load);

    }

    public getBudgetOfUser(month:string,year:string):Observable<string>{
        var load = {"month":month,"year":year};
        return this._http.post<string>("http://192.168.43.49:8080/account/budget/getuserbudget",load);
    }

    public saveBudgetOfUser(month:string,year:string,budget:string):Observable<string>{
        var load = {"month":month,"year":year,"budget":budget};
        return this._http.post<string>("http://192.168.43.49:8080/account/budget/savebudget",load);
    }

}