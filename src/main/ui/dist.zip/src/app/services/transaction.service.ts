import { Transaction } from './../model/tranactionModel';
import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpParams } from '@angular/common/http';
import { Observable, from } from 'rxjs';

export interface datepar {
  from: string;
  to: string;
}



@Injectable()
export class TransactionService {

  public transactions: Transaction[];

  constructor(private _http: HttpClient) {

  }
  public getAllTransaction():Observable<Transaction[]> {

    return this._http.get<Transaction[]>("http://192.168.43.49:8080/account/dashboard/getAll").pipe();

  }

  public SaveTransaction(transaction: Transaction): Observable<object> {
    return this._http.post("http://192.168.43.49:8080/account/dashboard/saveSingleRest", transaction).pipe();
  }


  public populateTransaction(){
    this._http.get<Transaction[]>("http://192.168.43.49:8080/account/dashboard/getAll").pipe().subscribe(data=>{
    console.log("populate Transaction",data);
    this.transactions = data;
    
    });
  }




  public getTransactionBetweenDates(formdate, todate): Observable<Transaction[]> {
    let url = new HttpParams();
    let d;
    // console.log(formdate +" :"+ todate);
    url.set("from", formdate);
    url.set("to", todate);
    console.log(url.toString());

    d = {
      from: formdate,
      to: todate
    }
    return this._http.post<Transaction[]>("http://192.168.43.49:8080/account/dashboard/getTransactionBetweenDates", d).pipe();

  }




}