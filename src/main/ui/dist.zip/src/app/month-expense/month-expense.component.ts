import { dailyTransactionServices } from './../services/dailyTransaction.service';
import { Transaction } from './../model/tranactionModel';
import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
// import { dailyTransactionServices } from '../services/dailyTransaction.service';
import * as d3 from 'd3';
import * as $ from 'jquery';

@Component({
  selector: 'app-month-expense',
  templateUrl: './month-expense.component.html',
  styleUrls: ['./month-expense.component.css'],
})
export class MonthExpenseComponent implements OnInit {
  month: string[] = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  monthDayCount: number[] = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  currentMonth: number;
  year: number;
  pipe = new DatePipe('en-US');
  max: string;
  min: string;
  maxDate: string;
  minDate: string;
  expectBudgetBurndown: any = [];
  acctualBudgetBurndown: any = [];
  constructor(private _dailyTransaction: dailyTransactionServices) { }

  ngOnInit() {
    var date = new Date()
    this.currentMonth = date.getMonth();
    this.year = date.getFullYear();

    // this.pipe.transform(Date.now(), 'yyyy-MM-dd');

    this.getTransaction();
    this.expectBudgetBurndown = [];

  }

  getTransaction() {
    this.expectBudgetBurndown = [];
    this.acctualBudgetBurndown = [];
    this._dailyTransaction.getMonthlyTransaction((this.currentMonth) + "", this.year + "").subscribe(data => {
      // console.log(data.transaction.length);
      var expense = [];
      var SendData = [];
      var lifestyle = 0;
      var essential = 0;
      var acctualBurnDownCounter = 0;
      var transaction = JSON.parse(JSON.stringify(data));
      for (let i = 0; i < transaction.transaction.length; i++) {
        var date = transaction.transaction[i].date;
        var trans = transaction.transaction[i].Transactions;
        var sum = 0;
        for (let j = 0; j < trans.length; j++) {
          sum += parseInt(trans[j].amount);
          if (trans[j].value == "Essentials") {
            essential += parseInt(trans[j].amount);
          }
          else {
            lifestyle += parseInt(trans[j].amount);
          }
        }
        acctualBurnDownCounter += sum;
        var tdate = date.split("-");
        tdate = new Date(tdate[2],(tdate[1]-1),tdate[0]);
        this.acctualBudgetBurndown.push({ "date": tdate, "amount": acctualBurnDownCounter });
        expense.push({ "letter": date, "frequency": sum });
        var tmp = [];
        tmp.push({ "transactions": trans });
        SendData.push({ "date": date, "trans": tmp[0] });
      }
      console.log(expense);
      console.log(SendData);
      console.log("liftstyle", lifestyle);
      console.log("essentials", essential);
      this.drawBarChart(expense, SendData);
      var tmp = [];
      tmp.push({ "region": "Essesntials", "count": essential });
      tmp.push({ "region": "Lifestyle", "count": lifestyle });
      var t = [];
      t.push({ "value": tmp });
      this.pie(t[0], "piechart");
      // transaction.transaction.each(a=>{
      //   console.log(a);
      // });


    });


    this._dailyTransaction.getMonthlyStats((this.currentMonth) + "", this.year + "").subscribe(data => {
      var jsonData = JSON.parse(JSON.stringify(data));
      this.min = jsonData.minimum_trans;
      this.max = jsonData.maximum_trans;
      this.maxDate = jsonData.maximum_trans_date;
      this.minDate = jsonData.minimum_trans_date;
    });

    /*leap year code is to be added*/
    this._dailyTransaction.getBudgetOfUser((this.currentMonth + 1) + "", this.year + "").subscribe(data => {
      var budget = JSON.parse(JSON.stringify(data)).budget;
      var perDayExpense = budget / this.monthDayCount[this.currentMonth];
      console.log("day count", this.monthDayCount[this.currentMonth], this.currentMonth + 1);
      console.log("perDayExpense", perDayExpense);
      console.log("budget", budget);
      console.log("date", new Date(this.year, this.currentMonth, 1));
      var spend = 0;
      for (let i = 0; i < this.monthDayCount[this.currentMonth]; i++) {
        spend += perDayExpense;
        this.expectBudgetBurndown.push({ "amount": spend, "date": new Date(this.year, this.currentMonth, (i + 1)) });
      }
      console.log(this.expectBudgetBurndown);


      this.drawLineChart(this.expectBudgetBurndown, "linechart", 7000, this.acctualBudgetBurndown);
      console.log(this.acctualBudgetBurndown);
    });

  }


  previousdate() {
    this.currentMonth = (this.currentMonth--) === 0 ? 11 : this.currentMonth;
    this.year = this.currentMonth == 11 ? --this.year : this.year;
    this.getTransaction();
  }

  nextDate() {
    this.currentMonth = (++this.currentMonth) === 12 ? 0 : this.currentMonth;
    this.year = this.currentMonth == 0 ? ++this.year : this.year;
    this.getTransaction();
  }


  drawBarChart(data, expenses): void {
    console.log("expenses", expenses);
    console.log("data", data);
    var div = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("padding", "6px")
      .style("background", "lightsteelblue")
      .style("border", "1px solid black")
      .style("border-radius", "5px")
      .style("opacity", 0);
    $("#chart").html("");
    width = (document.getElementById('chart-container').clientWidth);
    console.log(width);
    console.log(width);
    var svg = d3.select("#chart").append("svg").attr("width", width).attr("height", "300")
      .attr('preserveAspectRatio', 'xMinYMin'),
      margin = { top: 50, right: 20, bottom: 100, left: 40 },
      width = +svg.attr("width") - margin.left - margin.right,
      height = +svg.attr("height") - margin.top - margin.bottom;

    var x = d3.scaleBand().rangeRound([0, width]).padding(0.1),
      y = d3.scaleLinear().rangeRound([height, 0]);

    var g = svg.append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    x.domain(data.map(function (d) { return d.letter; }));
    y.domain([0, d3.max(data, function (d) { return d.frequency; })]);
    g.append("g")
      .attr("class", "axis axis-x")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(x)).selectAll("text")
      .style("text-anchor", "end")
      .attr("dx", "-.8em")
      .attr("dy", ".15em")
      .attr("transform", "rotate(-65)");

    g.append("g")
      .attr("class", "axis axis-y")
      .call(d3.axisLeft(y).ticks(10))
      .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 6)
      .attr("dy", "0.71em")
      .attr("text-anchor", "end")
      .text("Frequency");

    g.selectAll(".bar")
      .data(data)
      .enter().append("rect")
      .attr("class", "bar").attr("fill", "steelblue")
      .attr("x", function (d) { return x(d.letter); })
      .attr("y", function (d) { return y(d.frequency); })
      .attr("width", x.bandwidth())
      .attr("height", function (d) { return height - y(d.frequency); }).on("mouseover", function (d, i) {
        div.transition()
          .duration(400)
          .style("opacity", 1);
        div.style("left", (d3.event.pageX) + "px")
          .style("top", (d3.event.pageY - 28) + "px");
        var exp = "";
        for (let k = 0; k < expenses[i].trans.transactions.length; k++) {
          exp += "<div>" + expenses[i].trans.transactions[k].name + "(" + expenses[i].trans.transactions[k].amount + ")" + "</div>"
        }
        div.html(exp);
      }).on("mouseout", function (d, i) {
        div.style("opacity", 0);
        div.transition()
          .duration(200)
      })
    var tmp = 55;
    var fontSize;
    if (window.innerWidth <= 768) {
      tmp = 45;
      fontSize = 6 + "px";
    }
    else {
      fontSize = 10 + "px";
    }
    svg.selectAll("text.bar")
      .data(data)
      .enter().append("text")
      .attr("class", "t")
      .attr("font-size", fontSize)
      .attr("text-anchor", "middle")
      .attr("x", function (d, i) {
        return (($(".bar")[i] as any).x.animVal.value + tmp);       //---------------
      })
      .attr("y", function (d) {
        var tmp = y(d.frequency);
        return tmp == 0 ? (margin.top - 10) : (tmp + (margin.top - 10));
      })
      .text(function (d, i) { return data[i].frequency; });

    // svg.append("text").text("Datewise expense").attr("transform", "translate(100,30)").attr("font-size", "30px");
  }


  pie(data, chartPlace) {
    // alert("pie chart called");
    console.log(data);
    const width = $("#" + chartPlace).width();
    var height = $("#" + chartPlace).width();
    height = 250;
    if (width <= 400)
      height = 250;
    // alert(height+":"+width);
    const radius = (Math.min(width, height) / 2) - 10;
    // alert(height + " " + width);
    d3.select("#" + chartPlace).html("");
    const svg = d3.select("#" + chartPlace)
      .append("svg").attr("id", "chart-pie")
      .attr("width", width)
      .attr("height", height + 50)
      .append("g")
      .attr("transform", `translate(${(width / 2)}, ${(height / 2) + 10})`);

    var div = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("padding", "6px")
      .style("background", "lightsteelblue")
      .style("border", "1px solid black")
      .style("border-radius", "5px")
      .style("opacity", 0);
    const color = d3.scaleOrdinal(["#4682b4", "#91b3d0"]);
    const pie = d3.pie()
      .value(d => d.count)
      .sort(null);
    const arc = d3.arc()
      .innerRadius(0)
      .outerRadius(radius);
    function type(d) {
      d.value = Number(d.value);
      return d;
    }
    function arcTween(a) {
      const i = d3.interpolate(this._current, a);
      this._current = i(1);
      return (t) => arc(i(t));
    }
    const path = svg.selectAll("path")
      .data(pie(data["value"]));
    path.transition().duration(500).attrTween("d", arcTween);
    path.enter().append("path")
      .attr("fill", (d, i) => color(i))
      .attr("d", arc)
      .attr("cursor", "pointer")
      .attr("id", "pie")
      .attr("stroke", "white")
      .attr("stroke-width", "2px")
      .each(function (d) {
        this._current = d;
      }).on("mouseover", function (d, i) {
        div.transition()
          .duration(400)
          .style("opacity", 1);
        div.style("left", (d3.event.pageX) + "px")
          .style("top", (d3.event.pageY - 28) + "px");
        div.html(d.data.region + ":<b>" + d.value + "</b>");
      }).on("mouseout", function (d, i) {
        div.transition()
          .duration(400)
          .style("opacity", 0);
      });
    var group = d3.select("#chart-pie").append("g");
    for (let i = 0; i < data.value.length; i++) {
      var group1 = group.append('g').attr("transform", "translate(" + ((width / 2) - 50) + "," + ((height + 10) + (15 * i)) + ")")
      group1.append("rect").attr("width", "10").attr("height", "10").attr("fill", color(i));
      group1.append("text").text(data.value[i].region + "(" + data.value[i].count + ")").attr("fill", "black").attr("transform", "translate(15,10)");
    }
  }



  drawLineChart(y, element, budget, burndown): void {
    console.log(burndown);



    // burndown.forEach(element => {
    //   element  =  { date : d3.timeParse("%Y-%m-%d")(element.date), value : element.amount }
    //   console.log('elements',element);
    // });
    let minScale = 0;
    let maxScale = parseInt(budget);
    $("#" + element).html("");
    var margin = {
      top: 50,
      right: 50,
      bottom: 50,
      left: 50
    },
      width = 500 - margin.left - margin.right // Use the window's width 
      , height = window.innerWidth > 550 ? 400 : 300 // Use the window's height
    width = window.innerWidth > 550 ? (window.innerWidth - 100) : (window.innerWidth - 50);
    // The number of datapoints
    var n = y.length; //change

    var xScale = d3.scaleTime()
      .domain(d3.extent(y, function (d) {
        return d.date;
      }))
      .range([0, width]);
    // 6. Y scale will use the randomly generate number 
    var yScale = d3.scaleLinear().domain([maxScale, minScale]) // input 
      .range([height, 0]); // output 
    // 7. d3's line generator
    var line = d3.line()
      .x(function (d, i) {
        console.log(xScale(d.date));
        return xScale(d.date);
      })
      .y(function (d) {
        console.log(yScale(d.amount));
        return yScale(d.amount);
      })
      .curve(d3.curveMonotoneX)
       // apply smoothing to the line

    // 8. An array of objects of length N. Each object has key -> value pair, the key being "y" and the value is a random number
    var dataset = d3.range(n).map(function (d, i) {
      // var v = d3.randomUniform(1)();
      // console.log(y[i]);
      return {
        "y": y[i].amount   //change
      }
    })

    // var dataset2 = d3.range(burndown.length).map(function (d, i) {
    // //  console.log(burndown[i]);
    //   var v = d3.randomUniform(1)();
    //   return {
    //     "y": burndown[i].amount      //change
    //   }
    // })
    var svg = d3.select("#" + element).append("svg").attr("width",
      width).attr("height",
        height + margin.top + margin.bottom).append("g").attr(
          "transform",
          "translate(" + margin.left + "," + margin.top + ")");
    // 3. Call the x axis in a group tag
    svg.append("g").attr("class", "x axis").attr("transform",
      "translate(0," + height + ")").call(d3.axisBottom(xScale)); // Create an axis component with d3.axisBottom
    // 4. Call the y axis in a group tag
    svg.append("g").attr("class", "y axis").call(d3.axisLeft(yScale)); // Create an axis component with d3.axisLeft

    // 9. Append the path, bind the data, and call the line generator 
    // console.log(dataset);
    svg.append("path").datum(y) // 10. Binds data to the line 
      .attr("class", "line").attr("style", "fill: none;stroke: steelblue;stroke-width:3;cursor:pointer") // Assign a class for styling 
      .attr("d", line); // 11. Calls the line generator 
    svg.append("path").datum(burndown) // 10. Binds data to the line 
      .attr("class", "line").attr("style", "fill: none;stroke: #91b3d0;stroke-width:3;cursor:pointer") // Assign a class for styling 
      .attr("d", line);
  }
}

