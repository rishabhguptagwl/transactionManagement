import { TransactionService } from './../services/transaction.service';
import { Component, OnInit } from '@angular/core';


interface saving{
  date:String;
  amount:number;
}

@Component({
  selector: 'app-list-saving',
  templateUrl: './list-saving.component.html',
  styleUrls: ['./list-saving.component.css']
})
export class ListSavingComponent implements OnInit {
  saving:saving[]
  constructor(private _transactionServices :TransactionService) {


   }

  ngOnInit() {
      this.saving = [];
      this.getSaving();

  }

  public getSaving(){
    this._transactionServices.getAllTransaction().subscribe((data)=>{
      for(let i=0;i<data.length;i++){
        this.saving.push({
          date:data[i].date,
          amount:data[i].save
        });
      }
      console.log(this.saving);
    });
  }

}
