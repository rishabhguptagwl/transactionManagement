import { Component, OnInit } from '@angular/core';
import { TransactionService } from './../services/transaction.service';


interface trans{
  date:string;
  amount:number;
}




@Component({
  selector: 'app-transaction-data',
  templateUrl: './transaction-data.component.html',
  styleUrls: ['./transaction-data.component.css']
})
export class TransactionDataComponent implements OnInit {

  constructor(private _httpservice : TransactionService ) { }
  transArr: trans[];
  ngOnInit() {
    this.transArr = [];
    this.getTransaction();
  }


  public getTransaction(){
    
    this._httpservice.getAllTransaction().subscribe((data)=>{
        for(let i=0;i<data.length;i++){
          this.transArr.push({
            date:data[i].date,
            amount:data[i].amount
          });      
          
          
				}
				console.log(this.transArr);
        // console.log(y);
    });
  }

}
