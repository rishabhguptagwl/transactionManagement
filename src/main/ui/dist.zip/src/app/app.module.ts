import { dailyTransactionServices } from './services/dailyTransaction.service';
import { AnalyticsViewComponent } from './analytics-view/analytics-view.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListAllTransactionViewComponent } from './list-all-transaction-view/list-all-transaction-view.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { TransactionService } from './services/transaction.service';
import { InsertTransactionComponent } from './insert-transaction/insert-transaction.component';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TransactionViewComponent } from './transaction-view/transaction-view.component';
import { ListSavingComponent } from './list-saving/list-saving.component';
import { TransactionChartComponent } from './transaction-chart/transaction-chart.component';
import { TransactionDataComponent } from './transaction-data/transaction-data.component';
import { AnalyticsDashBoardComponent } from './analytics-dash-board/analytics-dash-board.component';
import { DailyTransactionComponent } from './daily-transaction/daily-transaction.component';
import { ListDailyTransactionsComponent } from './list-daily-transactions/list-daily-transactions.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatButton, MatButtonModule } from '@angular/material';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { MatRippleModule } from '@angular/material/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule,MatSelectModule } from '@angular/material';
import { MatDividerModule } from '@angular/material/divider';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import {MatTooltipModule} from '@angular/material/tooltip';
import { TodayExpenseComponent } from './today-expense/today-expense.component';
import { WeekExpenseComponent } from './week-expense/week-expense.component';
import { UnclassComponent } from './unclass/unclass.component';
import { MonthExpenseComponent } from './month-expense/month-expense.component';
import { IncomeDialogComponent } from './income-dialog/income-dialog.component';
import { NoTransactionEntryDialogComponent } from './no-transaction-entry-dialog/no-transaction-entry-dialog.component';
import { BudgeDialogComponent } from './budge-dialog/budge-dialog.component';
import { ROUTER_PROVIDERS } from '@angular/router/src/router_module';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    ListAllTransactionViewComponent,
    InsertTransactionComponent,
    AnalyticsViewComponent,
    TransactionViewComponent,
    AnalyticsComponent,
    ListSavingComponent,
    TransactionChartComponent,
    TransactionDataComponent,
    AnalyticsDashBoardComponent,
    DailyTransactionComponent,
    ListDailyTransactionsComponent,
    UserDashboardComponent,
    TodayExpenseComponent,
    WeekExpenseComponent,
    UnclassComponent,
    MonthExpenseComponent,
    IncomeDialogComponent,
    NoTransactionEntryDialogComponent,
    BudgeDialogComponent
  ],
  imports: [
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserModule,
    RouterModule.forRoot([
      { path: "view", component: TransactionViewComponent },
      { path: "analytics", component: DailyTransactionComponent },
      { path: "viewdata", component: AnalyticsDashBoardComponent },
      { path: "dailytransaction", component: ListDailyTransactionsComponent },
      {
        path: "dashboard", component: UserDashboardComponent, children: [
          { path: "today", component: TodayExpenseComponent },
          { path: "week", component: WeekExpenseComponent },
          { path: "month", component: MonthExpenseComponent },
          { path: "", component: TodayExpenseComponent }

        ]
      },
      { path: "unclassed", component: UnclassComponent }
    ],{ useHash: true }), BrowserAnimationsModule,
    MatCardModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRippleModule,
    MatExpansionModule,
    MatSidenavModule,
    MatListModule,
    MatDividerModule,
    MatSnackBarModule,
    MatSelectModule,
    MatButtonModule,
    MatTooltipModule
  ],
  providers: [TransactionService, dailyTransactionServices, MatDatepickerModule,{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent],
  entryComponents:[IncomeDialogComponent,NoTransactionEntryDialogComponent,BudgeDialogComponent]
})
export class AppModule { }