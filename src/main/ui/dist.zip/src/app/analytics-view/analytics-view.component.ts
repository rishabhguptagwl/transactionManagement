import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analytics-view',
  templateUrl: './analytics-view.component.html',
  styleUrls: ['./analytics-view.component.css']
})
export class AnalyticsViewComponent implements OnInit {
  toggle:boolean;
  filter:boolean;
  constructor() { }

  ngOnInit() {
    this.toggle = true;
    this.filter = false;
  }


  toggleData(){
    this.toggle = !this.toggle;
  }

  filterInverse(){
    this.filter = !this.filter;
  }

}
